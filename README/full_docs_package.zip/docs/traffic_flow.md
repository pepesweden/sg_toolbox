# 🔄 Traffic Flow

This document outlines the **real traffic and processing flow** for the summary generation backend.

It reflects how data moves between components, especially with regard to PII handling and OpenAI integration.

---

## ✅ Sequential Flow Overview

1. 👤 **User Upload**  
   - Uploads `.docx`, selects preferences and templates via the frontend UI.

2. 🌐 **Frontend**  
   - Sends the document and preferences to the backend API.

3. 🕵️ **PII Handler – Step 1: Anonymization**  
   - Extracts and masks PII (e.g. names, organizations, emails).
   - Stores an encrypted, in-memory map for later reinsertion.

4. 🧠 **OpenAI Engine**  
   - Receives the anonymized text.
   - Builds prompts using user preferences and templates.
   - Handles token limits and performs one or more API calls.
   - Returns a summarized output (still anonymized).

5. 🕵️ **PII Handler – Step 2: Reinjection**  
   - Decrypts and re-applies original PII into the generated summary text.

6. 📄 **DOCX Formatter**  
   - Applies document style and formatting (font, headings, logo).
   - Outputs a styled `.docx` file.

7. 🌐 **Frontend**  
   - Sends the finished `.docx` file to the user for download.

---

## 📦 Notes
- No PII is sent to OpenAI.
- The PII map exists **only in RAM** and is discarded after use.
- Each step is modular and can become its own microservice.

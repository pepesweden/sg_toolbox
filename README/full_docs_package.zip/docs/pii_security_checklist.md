# 🛡️ PII Reinjection Security Checklist

This document outlines the security precautions and mitigation strategies to manage PII during reinjection after OpenAI summary generation.

---

## ✅ Key Risks

| Category         | Description                                                  | Risk Level |
|------------------|--------------------------------------------------------------|------------|
| OpenAI Exposure  | PII sent to GPT API                                          | ✅ Very Low |
| In-Memory Mapping| PII stored temporarily for reinjection                       | 🟡 Medium   |
| File Output      | PII appears in downloadable .docx file                       | 🟡 Medium   |
| Persistent Storage| PII written to DB or logs                                   | ✅ None (if avoided) |

---

## 🔐 Mitigation Strategies

### 🔹 Memory Handling
- [ ] Store PII mapping **only in memory** — never write to disk.
- [ ] Use **encryption in RAM** for all temporary PII maps.
- [ ] **Automatically destroy** mapping after reinjection step.
- [ ] Run reinjection in an **ephemeral subprocess or Docker container** to isolate scope and auto-cleanup on crash.

### 🔹 File Output
- [ ] Store output `.docx` in a **temp directory** with auto-delete.
- [ ] Optionally **encrypt output files** at rest (if persisted even briefly).
- [ ] Apply access controls or **user scoping** on download URLs.
- [ ] Add **auto-expiry** (e.g. 15 min TTL) to output files.

### 🔹 Access Monitoring
- [ ] Log **PII reinjection events** with user + timestamp.
- [ ] Log **file downloads** including filename, user, and IP.

### 🔹 Developer Controls
- [ ] Add config flag `PII_REINSERTION_ENABLED = True/False` (for dev/test environments).
- [ ] Run PII-sensitive logic in **its own container or service**, if moving toward microservices.

---

## 🧪 Optional (Paranoia Mode)
- Use a **RAM disk** (`tmpfs`) if file storage is unavoidable.
- Implement **Zero Trust policies** for internal services (e.g. only allow reinjection via secure channel).

